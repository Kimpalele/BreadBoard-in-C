Compilation command: gcc functions.c breadboard.c -Wall
Har dubbelkollat och koden ska inte visa några warnings med -Wall kommandot.
när man startar programmet vill det ha en input på storleken av breadboarden man skapar,
syntaxen för storleken skrivs in som " 'x' mellanslag 'y' ". Så allt på samma rad!
Det finns ett par buggar jag är medveten om men som jag inte riktigt har lyckats korrigera, 
Men programmet funkar som det ska och är körbart trots buggarna.